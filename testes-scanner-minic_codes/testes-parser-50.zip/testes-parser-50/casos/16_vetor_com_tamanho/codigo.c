int dados[10];
