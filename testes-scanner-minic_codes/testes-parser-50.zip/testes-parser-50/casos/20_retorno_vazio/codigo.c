void espera() { return; }
